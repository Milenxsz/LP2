﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;  // globais

      
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtnumero2.Clear();
            txtresultado.Clear();
            txtNumero1.Focus();
            resultado = 0;
        }

        private void TxtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("Número inválido!!!");
                txtNumero1.Focus();
            }
        }

        private void Txtnumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero2.Text, out numero2))
            {
                MessageBox.Show("Número inválido!!!");
                txtnumero2.Focus();
            }
        }


        private void BtnMais_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void BtnVezes_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes)
            {
                Close();
            }
        }

        private void BtnMenos_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void Txtnumero2_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por 0!!!", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtnumero2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtresultado.Text = resultado.ToString();
            }
        }

        

    }
}
