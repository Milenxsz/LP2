﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVestibular
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnReceber_Click(object sender, EventArgs e)
        {
            int[,] cursos = new int[8,4];
            string auxiliar = "";
            int [] saida  = new int [2];
            int [] soma = new int[8];
            
            for (int curso = 0; curso < 8; curso++)
            {
                for (int ano = 0; ano < 4; ano++)
                {
                    auxiliar = Interaction.InputBox($"Digite a quantidade de alunos do curso {curso + 1} do ano {ano + 1}");
                    if (!int.TryParse(auxiliar, out cursos[curso, ano]) || cursos[curso, ano] < 0)
                    {
                        MessageBox.Show("Valor inválido");
                        ano--;
                    }
                    else
                    {
                        listBox1.Items.Add($"Total do curso {curso+1} do Ano {ano+1}: {cursos[curso, ano]}");
                        if (ano == 3)
                        {
                            soma[curso] = cursos[curso, 0] + cursos[curso, 1] + cursos[curso, 2] + cursos[curso, 3];
                            listBox1.Items.Add($"Total curso: {soma[curso]}");
                        }
                    }
                 
                  
                }
               
            }
            saida[1] = soma[0] + soma[1] + soma[2] + soma[3] + soma[4] + soma[5] + soma[6] + soma[7];
            listBox1.Items.Add($"Total Geral: {saida[1]}");




        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
